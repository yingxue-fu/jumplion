"""
Python-native MaxLFQ, backed by a C++ extension ported from tvpham/iq
(https://github.com/tvpham/iq, BSD-3-Clause), with the R (.Call/SEXP)
layer removed.

Mirrors the interface and behavior of R's `iq::fast_MaxLFQ()`.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

import numpy as np

from . import _iq_native  # compiled extension, see _iq_native/src/bindings.cpp


@dataclass
class MaxLFQResult:
    estimate: np.ndarray          # (n_proteins, n_samples) log2 abundance matrix
    protein_names: list[str]      # row labels, in estimate's row order
    sample_names: list[str]       # column labels, in estimate's column order
    annotation: list[str]         # per-protein connectivity annotation (matches iq's $annotation)


def fast_maxlfq(
    protein_list: Sequence[str],
    sample_list: Sequence[str],
    ion_id: Sequence,
    quant: Sequence[float],
) -> MaxLFQResult:
    """
    Estimate relative protein abundances with MaxLFQ.

    Parameters
    ----------
    protein_list : one protein id per observation (parallel to sample_list/ion_id/quant)
    sample_list  : one sample id per observation
    ion_id       : one fragment/ion/precursor id per observation (grouping key,
                   analogous to `norm_data$id` in R's fast_MaxLFQ)
    quant        : log2 intensity per observation (already filtered/normalized,
                   same expectation as R's fast_MaxLFQ input)

    Returns
    -------
    MaxLFQResult
    """
    protein_list = np.asarray(protein_list)
    sample_list = np.asarray(sample_list)
    ion_id = np.asarray(ion_id)
    quant = np.asarray(quant, dtype=np.float64)

    if not (len(protein_list) == len(sample_list) == len(ion_id) == len(quant)):
        raise ValueError("protein_list, sample_list, ion_id, quant must have equal length")
    if np.isnan(quant).any():
        raise ValueError("NA value in quant")

    # factorize to 0-based dense codes, same role as R's factor(...) calls
    # before .Call("iq_MaxLFQ", ...) in fast_MaxLFQ()
    proteins, protein_codes = np.unique(protein_list, return_inverse=True)
    samples, sample_codes = np.unique(sample_list, return_inverse=True)
    _, ion_codes = np.unique(ion_id, return_inverse=True)

    raw = _iq_native.run_maxlfq(
        protein_codes.astype(np.int32).tolist(),
        ion_codes.astype(np.int32).tolist(),
        sample_codes.astype(np.int32).tolist(),
        quant.tolist(),
    )

    return MaxLFQResult(
        estimate=np.asarray(raw["estimate"]),
        protein_names=[str(proteins[i]) for i in raw["row_protein_index"]],
        sample_names=[str(samples[j]) for j in raw["col_sample_index"]],
        annotation=list(raw["annotation"]),
    )
